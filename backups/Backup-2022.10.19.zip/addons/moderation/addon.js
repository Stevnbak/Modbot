require('./actions');
require('./autoActions');
require('./commands');
