//@ts-check

const ONE_HOUR = 60000 * 60;
const ONE_DAY = ONE_HOUR * 24;

/**
 * @param {number} remaining ms to format.
 */
module.exports = (remaining) => {
    const days = Math.floor(remaining / ONE_DAY);
    remaining -= days * ONE_DAY;
    const hours = Math.floor(remaining / ONE_HOUR);
    remaining -= hours * ONE_HOUR;
    const minutes = Math.floor(remaining / 60000);
    remaining -= minutes * 60000;
    const seconds = Math.floor(remaining / 1000);
    if (days) {
        if (hours) {
            return `${days} day${days > 1 ? 's' : ''} and ${hours} hour${hours > 1 ? 's' : ''}`;
        } else if (minutes) {
            return `${days} day${days > 1 ? 's' : ''} and ${minutes} minute${minutes > 1 ? 's' : ''}`;
        }
        return `${days} day${days > 1 ? 's' : ''}`;
    } else if (hours) {
        if (minutes) {
            return `${hours} hour${hours > 1 ? 's' : ''} and ${minutes} minute${minutes > 1 ? 's' : ''}`;
        }
        return `${hours} hour${hours > 1 ? 's' : ''}`;
    } else if (minutes) {
        if (seconds) {
            return `${minutes} minute${minutes > 1 ? 's' : ''} and ${seconds} second${seconds > 1 ? 's' : ''}`;
        }
        return `${minutes} minute${minutes > 1 ? 's' : ''}`;
    } else if (seconds) {
        return `${seconds} seconds`;
    }
    return '';
};
