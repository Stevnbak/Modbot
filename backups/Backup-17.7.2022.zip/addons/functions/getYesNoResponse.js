const getSelection = require('./getSelection');

module.exports = ({ embed, channel, user }, time = 300000) =>
    getSelection(user, channel, embed, {
        time,
        options: [
            {
                text: 'Yes',
                id: true,
            },
            {
                text: 'No',
                id: false,
            },
        ],
    });
