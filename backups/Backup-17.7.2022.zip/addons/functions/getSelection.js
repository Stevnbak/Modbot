//@ts-check
const emotes = ['🇦', '🇧', '🇨', '🇩', '🇪', '🇫', '🇬', '🇭', '🇮', '🇯'];

const numberEmotes = ['1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '🔟'];

const arrows = ['◀', '▶'];

/**
 *
 * @param {Bot.Message} message
 * @param {import("discord.js").EmojiIdentifierResolvable[]} reactionsLeft
 */
const reactUntilGone = async (message, reactionsLeft) => {
    if (!message.editable || reactionsLeft.length === 0) return; //Ok, the message was deleted, or we ran out of reactions.
    try {
        await message.react(reactionsLeft[0]);
    } catch (error) {
        return; //Ok, we couldn't react.
    }
    await reactUntilGone(message, reactionsLeft.slice(1));
};

// {embed, channel, user, type}, options, time = 300000

/**
 * @typedef GetSelectionDataFields
 * @property {"text"|"numbers"} [type="text"]
 * @property {true} fields
 * @property {number} [time=300000]
 * @property {GetSelectionOptionFields[]|Promise<GetSelectionOptionFields>[]} options
 */

/**
 * @typedef GetSelectionDataText
 * @property {"text"|"numbers"} [type="text"]
 * @property {false} [fields]
 * @property {number} [time=300000]
 * @property {GetSelectionOptionText[]|Promise<GetSelectionOptionText>[]} options
 */

/**
 * @typedef GetSelectionOptionFields
 * @property {string} title
 * @property {string} value
 * @property {any} id id to return if this option is selected.
 */

/**
 * @typedef GetSelectionOptionText
 * @property {string} text If this option is used as a string.
 * @property {any} id id to return if this option is selected.
 */

/**
 * Get a selection from a user.
 * @param {import("discord.js").User} user
 * @param {import("discord.js").TextChannel|import("discord.js").DMChannel} channel
 * @param {import("discord.js").MessageEmbed} embed
 * @param {GetSelectionDataFields|GetSelectionDataText} data
 */
module.exports = async (user, channel, embed, data) => {
    /** @type {Bot.Message} */
    let selectionMessage;
    let oLength = 0;

    /** @type {GetSelectionOptionFields[]} */
    let fieldOptions = [];
    /** @type {GetSelectionOptionText[]} */
    let textOptions = [];

    // Used for text selections.
    let oldDescription = '';

    const emotesToUse = (data.type || 'text') === 'numbers' ? numberEmotes : emotes;

    if (data.fields) {
        fieldOptions = await Promise.all(data.options);
        oLength = fieldOptions.length > 3 ? 3 : fieldOptions.length; //We only allow x options per page.

        for (let i = 0; i < oLength; i++) {
            embed = embed.addField(`${emotesToUse[i]} ${fieldOptions[i].title}`, fieldOptions[i].value);
        }
    } else {
        textOptions = await Promise.all(data.options);
        oLength = textOptions.length > 10 ? 10 : textOptions.length; //We only allow x options per page.

        oldDescription = embed.description || ''; //We need to store this because we edit the description.
        embed = embed.setDescription(
            `${oldDescription}\n${emotesToUse
                .slice(0, oLength)
                .map((emoji, index) => `${emoji} ${textOptions[index].text}`)
                .join('\n')}`
        );
    }

    try {
        selectionMessage = /** @type {Bot.Message} */ (await channel.send({ content: '' + user, embeds: [embed] }));
    } catch (error) {
        return; //We couldn't send the message.
    }

    /** @type {import("discord.js").EmojiIdentifierResolvable[]} */
    let reactions;
    if (data.options.length > oLength) {
        reactions = [arrows[0], ...emotesToUse.slice(0, oLength), arrows[1]];
    } else {
        reactions = emotesToUse.slice(0, oLength);
    }
    reactUntilGone(selectionMessage, reactions);

    const choice = await new Promise((resolve) => {
        let page = 0; //We are on page 0.

        const collector = selectionMessage.createReactionCollector((reaction, u) => reactions.includes(reaction.emoji.name) && u.id === user.id, {
            time: data.time || 300000,
        });

        collector.on('collect', async (reaction) => {
            if (arrows.includes(reaction.emoji.name)) {
                try {
                    await reaction.remove(user);
                } catch (_) {}
                //We're switching the page.

                if (arrows[0] === reaction.emoji.name) {
                    //back.
                    if (page === 0) return; //No u.
                    page--;
                } else {
                    //forward.
                    // TODO: Get back to this and figure out why this works. Clean up later.
                    if (page === Math.floor(data.options.length + (data.options.length % oLength === 0 ? 0 : oLength - (data.options.length % oLength))) / oLength - 1) return; //We're already at the max pages.
                    page++;
                }

                if (data.fields) {
                    const newOptions = fieldOptions.slice(page * oLength, page * oLength + oLength);

                    embed.fields = [];
                    for (let i = 0; i < newOptions.length; i++) {
                        embed = embed.addField(`${emotesToUse[i]} ${newOptions[i].title}`, newOptions[i].value);
                    }
                } else {
                    const newOptions = textOptions.slice(page * oLength, page * oLength + oLength);
                    embed = embed.setDescription(
                        `${oldDescription}\n${emotesToUse
                            .slice(0, newOptions.length)
                            .map((emoji, index) => `${emoji} ${newOptions[index].text}`)
                            .join('\n')}`
                    );
                }
                try {
                    await reaction.message.edit(user, embed);
                } catch (error) {
                    //Oof, we couldn't edit the message, o well.
                }
            } else {
                //Omg, we picked something.
                const selected = (data.fields ? fieldOptions : textOptions)[page * oLength + emotesToUse.indexOf(reaction.emoji.name)];
                if (!selected) return; //O, this uh. Doesn't exist.
                collector.stop();
                resolve(selected.id);
            }
        });
        collector.on('end', async () => {
            if (!selectionMessage.deletable) return;
            await selectionMessage.delete();
            resolve(null);
        });
    });
    return choice;
};
