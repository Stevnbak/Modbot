//@ts-check
/**
 * @typedef MultipleResponseData
 * @property {import("discord.js").User} user
 * @property {import("discord.js").TextChannel|import("discord.js").DMChannel} channel
 * @property {?boolean} [delete=true] Delete messages that are sent as responses?
 * @property {?(message : import("discord.js").Message) => boolean} [filter]
 */

/**
 * Recieve multiple responses from the user.
 * @param {MultipleResponseData} data
 * @param {[(import("discord.js").MessageOptions | import("discord.js").MessageAttachment | import("discord.js").MessageEmbed | undefined)]} messageOptions
 * @returns {Promise<import("discord.js").Message[]>}
 */
module.exports = async (data, ...messageOptions) => {
    const options = Object.assign(
        {
            filter: () => true,
            delete: true,
        },
        data
    );
    let questionMessage;
    try {
        questionMessage = /** @type {import("discord.js").Message} */ (await data.channel.send.apply(data.channel, messageOptions));
    } catch (_) {
        return [];
    }
    const collector = data.channel.createMessageCollector({ filter: (message) => message.author.id === data.user.id && message.channel.id === data.channel.id });

    const response = await new Promise((resolve) => {
        /** @type {import("discord.js").Message[]} */
        const responses = [];

        collector.on('collect', async (message) => {
            if (message.content.toLocaleLowerCase() === 'cancel') {
                collector.stop();
                if (options.delete && message.deletable) {
                    try {
                        await message.delete();
                    } catch (_) {}
                }
                resolve(null);
            } else if (message.content.toLocaleLowerCase() === 'done') {
                collector.stop();
                if (options.delete && message.deletable) {
                    try {
                        await message.delete();
                    } catch (_) {}
                }
                resolve(responses);
            } else if (options.filter(message)) {
                responses.push(message);
                if (options.delete && message.deletable) {
                    try {
                        await message.delete();
                    } catch (_) {}
                }
            }
        });
    });
    if (questionMessage.deletable && options.delete) {
        try {
            await questionMessage.delete();
        } catch (_) {}
    }
    return response;
};
