//@ts-check
/**
 * @param {import("discord.js").TextChannel|import("discord.js").DMChannel} channel
 * @param {(message : import("discord.js").Message) => boolean} filter
 */
module.exports = async (channel, filter = () => true) => {
    const response = (await channel.awaitMessages({ filter, max: 1, time: 60000 * 5 })).first();
    if (response) {
        if (response.deletable) {
            try {
                await response.delete();
            } catch (_) {}
        }
    }
    return response;
};
