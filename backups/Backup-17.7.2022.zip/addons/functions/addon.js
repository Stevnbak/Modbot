//@ts-check
require('./bot'); //Other bot stuff

//Utils stuff:
const { ExportManager, Client } = Bot;

//Get any response from the user provided.
ExportManager.export('utils.getResponse', require('./getResponse'));

// Get multiple responses.
ExportManager.export('utils.getMultipleResponses', require('./getMultipleResponses'));

//Get any numerical response from the user provided.
ExportManager.export('utils.getNumericalResponse', require('./getNumericalResponse'));

//Get a reaction.
ExportManager.export('utils.getReaction', require('./getReaction'));
ExportManager.export('utils.getReactions', require('./getReactions'));

//Create a message with reactions to navigate the "pages".
ExportManager.export('utils.createPages', require('./createPages'));

//Create a message which the user can select an option.
ExportManager.export('utils.getSelection', require('./getSelection'));

// Create a message which lets the user select one of several emoji
ExportManager.export('utils.getEmojiSelection', require('./getEmojiSelection'));

// Create a message that asks the user to respond with yes or no.
ExportManager.export('utils.getYesNoResponse', require('./getYesNoResponse'));

// Create a message that asks the user to tag someone.
ExportManager.export('utils.getTaggedUser', require('./getTaggedUser'));

// Create an embed with standard colors
ExportManager.export('utils.createMessage', require('./createMessage'));

// Await a message in a channel.
ExportManager.export('utils.awaitMessage', require('./awaitMessage'));

// Format an amount of ms to a string.
ExportManager.export('utils.formatTimeLeft', require('./formatTimeLeft'));
