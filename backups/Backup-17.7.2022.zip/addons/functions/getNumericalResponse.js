module.exports = async (user, channel, ...messageOptions) => {
    let questionMessage;
    if (messageOptions.length > 0) {
        try {
            questionMessage = await channel.send.apply(channel, messageOptions);
        } catch (_) {
            return; //We can't send the message, how are we supposed to get a response?
        }
    }
    const response = (
        await channel.awaitMessages((m) => m.author.id === user.id && ((!isNaN(m.content) && isFinite(m.content)) || m.content.toLocaleLowerCase() === 'cancel'), {
            max: 1,
            time: 60000 * 5,
        })
    ).first();
    if (response && response.deletable) {
        try {
            await response.delete();
        } catch (_) {}
    }
    if (questionMessage && questionMessage.deletable) {
        try {
            await questionMessage.delete();
        } catch (_) {}
    }
    return !!response && response.content.toLocaleLowerCase() !== 'cancel' ? Number(response.content) : null;
};
