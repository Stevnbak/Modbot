//@ts-check

//Purpose: Basic help command.
const { MessageEmbed } = require('discord.js');
const { CommandManager, BotListeners, ExportManager, Client, StorageManager, Console } = Bot;

const quotes = [''];

const USER_MESSAGES_STORAGE_KEY = 'bot-user-messages-count';

/** @type {{[id : string]: number}} */
//const userMessages = StorageManager.get(USER_MESSAGES_STORAGE_KEY) || {};

/**
 * Applies reactions to the message until the message is deleted or all have been applied.
 * @param {import('discord.js').Message} message
 * @param {(import('discord.js').EmojiIdentifierResolvable)[]} reactionsLeft
 */
const reactUntilGone = async (message, reactionsLeft) => {
    if (!message.deletable || reactionsLeft.length === 0) return; //Ok, the message was deleted, or we ran out of reactions.
    try {
        await message.react(reactionsLeft[0]);
    } catch (error) {
        return; //Ok, we couldn't react.
    }
    await reactUntilGone(message, reactionsLeft.slice(1));
};

const helpMenu = [
    {
        emoji: '💼',
        category: 'Misc',
        color: 0xffff00,
    },
];

const botOwnerData = {
    emoji: '🛑',
    category: 'Botowner Commands',
    color: 0xffffff,
};

BotListeners.on('disconnect', () => Console.log('Bot had enuf of dis, Bot has disconnected.', null));
BotListeners.on('error', ({ message }) => Console.error(`Bot had a networking error! ${message}`));

//Help command currently doesn't work
/*CommandManager.add(
    'help',
    {
        category: 'Misc',
        description: 'Displays this message.'
    },
    async (message) => {
        const {GUILD_ID} = ExportManager.import('config');
        if (message.deletable) await message.delete().catch(() => null);
        const mainGuild = Client.guilds.cache.get(GUILD_ID);
        if (!mainGuild) return;
        /**
         * @param {string | { name: string }} emoji
        const getEmoji = (emoji) =>
            typeof emoji === 'string'
                ? emoji
                : mainGuild.emojis.find(({name}) => name === emoji.name).name;

        //Redo is called when someone wants to go back to the menu.
        const redo = async () => {
            let helpMessage;

            const categories = CommandManager.botowners.includes(
                message.author.id
            )
                ? helpMenu.concat([botOwnerData])
                : helpMenu;

            try {
                helpMessage = /** @type {import("discord.js").Message}  (
                    await message.reply(
                        new MessageEmbed()
                            .setDescription(
                                `What would you like to learn more about?

${categories
    .map(({emoji, category}) => `${getEmoji(emoji)} **${category}**`)
    .join('\n\n')}`
                            )
                            .setColor(0xff8800)
                            .setFooter(
                                'Click one of the icons below to learn more!'
                            )
                    )
                );
            } catch (error) {
                return;
            }
            const emojis = categories.map(({emoji}) => getEmoji(emoji));
            reactUntilGone(helpMessage, emojis);

            const getReaction = ExportManager.import('utils.getReaction');
            const reaction = await getReaction(
                message.author,
                helpMessage,
                emojis
            );
            if (!reaction) return;
            if (helpMessage.deletable) await helpMessage.delete();
            try {
                const menuItem = categories.find(
                    ({emoji}) =>
                        (typeof emoji === 'string' ? emoji : emoji) ===
                        reaction.emoji.name
                );
                if (!menuItem) return; // Should never happen unless categories is changed before the user reacts.

                const infoMessage =
                    /** @type {import("discord.js").Message} (
                        await message.channel.send({
                            embeds: [
                                new MessageEmbed()
                                    .setTitle(menuItem.category)
                                    .setDescription(
                                        CommandManager.commands
                                            .filter(
                                                (command) =>
                                                    command.category ===
                                                        menuItem.category &&
                                                    !command.hide
                                            )
                                            .sort((cA, cB) =>
                                                cA.cmd[0].localeCompare(
                                                    cB.cmd[0]
                                                )
                                            )
                                            .sort(
                                                (cA, cB) => cB.index - cA.index
                                            )
                                            .map(
                                                (command) =>
                                                    `**${CommandManager.prefix}${command.cmd[0]}** - ${command.description}`
                                            ).toString()
                                    )
                                    .setColor(menuItem.color)
                            ]
                        })
                    );

                const backReaction = await infoMessage.react('◀');
                const goBack = await getReaction(message.author, infoMessage, [
                    '◀'
                ]);
                if (!goBack) {
                    //They don't want to go back. Timeout.
                    try {
                        await backReaction.remove();
                    } catch (error) {}
                    return;
                } else {
                }
                if (infoMessage.deletable) await infoMessage.delete();
            } catch (error) {
                return; //Couldn't send message.
            }
            redo();
        };

        redo();
    }
);*/
