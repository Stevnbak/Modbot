module.exports = async (user, message, ...messageOptions) => {
    let questionMessage;
    try {
        questionMessage = await message.channel.send(...messageOptions);
    } catch (error) {
        return; //We can't send the message, how are we supposed to get a response?
    }
    const response = (
        await message.channel.awaitMessages((m) => m.mentions.users.first() && m.author.id === user.id, {
            max: 1,
            time: 60000 * 5,
        })
    ).first();
    if (response && response.deletable) await response.delete();
    if (questionMessage.deletable) await questionMessage.delete();
    return response ? response.mentions : null;
};
