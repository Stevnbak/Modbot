//@ts-check
module.exports = {};
const { ExportManager } = Bot;

/**
 * @typedef CreatePageOptions
 * @property {import("discord.js").TextChannel|import("discord.js").DMChannel} channel Channel to send the message in.
 * @property {string[]|Promise<string>[]} options Options to display.
 * @property {?number} [optionsPerPage] Options to show per page.
 * @property {?(data : PageChangeData, page : number) => { footer : string, title : string }} [onPageChange] Called on initialization and when switching pages. The page starts at zero.
 */

/**
 * @typedef PageChangeData
 * @property {string} title Title of the page.
 * @property {string} footer Footer of the page.
 */

const arrows = ['◀', '▶'];

/**
 * Create a message with pages.
 * @param {CreatePageOptions} data
 */
const createPages = async (data) => {
    const options = await Promise.all(data.options);

    const { regularMessage } = ExportManager.import('utils.createMessage');

    let pageData = {
        title: 'Page 1',
        footer: 'Click the reactions at the bottom to navigate.',
    };
    let page = 0;

    const optionsPerPage = data.optionsPerPage || 10;

    if (data.onPageChange) {
        pageData = data.onPageChange(pageData, page);
    }

    /** @type {Bot.Message} */
    let message;
    try {
        message = /** @type {Bot.Message} */ (await data.channel.send({ embeds: [regularMessage(options.slice(0, optionsPerPage).join('\n')).setTitle(pageData.title).setFooter(pageData.footer)] }));
    } catch (_) {
        return;
    }
    message
        .react(arrows[0])
        .then(() => message.react(arrows[1]))
        .catch(() => null);

    const collector = message.createReactionCollector((reaction, user) => arrows.includes(reaction.emoji.name) && !user.bot, {
        time: 60000 * 10,
    });
    collector.on('collect', async (reaction) => {
        if (reaction.message.channel.type === 'text') {
            const permissions = /** @type {import("discord.js").TextChannel} */ (reaction.message.channel).permissionsFor(reaction.message.client.user);
            if (permissions && permissions.has('MANAGE_MESSAGES')) {
                try {
                    await reaction.remove(reaction.users.last());
                } catch (_) {}
            }
        }

        if (reaction.emoji.name === arrows[0]) {
            if (page <= 0) {
                return;
            }
            page--;
        } else {
            if (page === Math.ceil(options.length / optionsPerPage) - 1) {
                return;
            }
            page++;
        }

        if (data.onPageChange) {
            pageData = data.onPageChange(pageData, page);
        } else {
            pageData.title = `Page ${page + 1}`;
        }

        const newEmbed = regularMessage(options.slice(page * optionsPerPage, page * optionsPerPage + optionsPerPage).join('\n'))
            .setTitle(pageData.title)
            .setFooter(pageData.footer);

        try {
            await message.edit(newEmbed);
        } catch (_) {}
    });
};

module.exports = createPages;
