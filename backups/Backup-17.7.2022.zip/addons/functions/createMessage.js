// @ts-check

const { MessageEmbed } = require('discord.js');

/**
 * Creates a helper to make a message with the specified color.
 * @param {number} color
 * @returns {(message: string) => MessageEmbed}
 */
const createHelper = (color) => (message) => new MessageEmbed().setDescription(message).setColor(color);

module.exports = {
    errorMessage: createHelper(0xff0000),
    successMessage: createHelper(0x00ff00),
    regularMessage: createHelper(0xff8800),
    /**
     * @param {string} message
     * @param {number} color
     */
    customMessage: (message, color) => createHelper(color)(message),
};
