//@ts-check

const getReaction = require('./getReaction');

/**
 * @typedef GetEmojiSelectionOptions
 * @property {import("discord.js").MessageEmbed} embed
 * @property {import("discord.js").TextChannel | import("discord.js").DMChannel} channel
 * @property {import("discord.js").User} user
 * @property {(string | import("discord.js").Emoji | import("discord.js").ReactionEmoji)[]} options
 * @property {number|undefined} [time]
 */

/**
 * @param {GetEmojiSelectionOptions} options
 * @returns {Promise<string | null>} the name of the emoji which the user reacted with
 */
module.exports = async ({ embed, channel, user, options, time }) => {
    const message = /** @type {Bot.Message} */ (await channel.send({ embeds: [embed] }));

    for (const item of options) {
        try {
            await message.react(item);
        } catch (_) {}

        // Check for user input between adding reactions for a better user experience.
        const userChoice = message.reactions.find((r) => r.users.has(user.id) && (options.includes(r.emoji) || options.includes(r.emoji.name)));

        if (userChoice) {
            return userChoice.emoji.name;
        }
    }

    const reaction = await getReaction(user, message, options, time);
    if (message.deletable) {
        try {
            await message.delete();
        } catch (_) {}
    }
    return reaction ? reaction.emoji.name : null;
};
