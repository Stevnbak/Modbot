// @ts-check

/**
 * @param {import("discord.js").User} userToCheck
 * @param {Bot.Message} message
 * @param {(string | import("discord.js").Emoji | import("discord.js").ReactionEmoji)[]} validReactions
 * @param {number} time
 * @returns {Promise<import("discord.js").MessageReaction | null>}
 */
module.exports = async (userToCheck, message, validReactions, time = 60000 * 5) => {
    const response = (
        await message.awaitReactions((reaction, user) => (validReactions.includes(reaction.emoji.name) || validReactions.includes(reaction.emoji)) && user.id === userToCheck.id, {
            time,
            max: 1,
        })
    ).first();
    return response;
};
