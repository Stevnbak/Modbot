//@ts-check
require('./test'); //DebugManager
