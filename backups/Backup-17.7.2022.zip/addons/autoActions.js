const {StorageManager, Console, ExportManager} = Bot;
const {CommandManager, ChatResponder, Client, BotListeners} = Discord;
const modFunctions = require('./functions');
const modActions = require('./modActions');
//Check if action has ran out of time
setInterval(function () {
    Client.guilds.cache.forEach((guild) => {
        var actions = StorageManager.discordGet('activeMod', guild.id) ? StorageManager.discordGet('activeMod', guild.id) : {};
        for (action in actions) {
            var start = actions[action]['date'];
            var length = actions[action]['length'];
            var type = actions[action]['action'];
            if (Date.now() >= start + length * 1000) {
                modActions.doUndoAction(type, actions[action]['username'], actions[action]['user'], Client.user, 'Auto', null, guild);
                delete actions[action];
            }
        }
        StorageManager.discordSet('activeMod', actions, guild.id);
    });
}, 60 * 1000);

//Log manual mod actions
BotListeners.on('guildMemberRemove', async function (/** @type {import('discord.js').GuildMember} */ member) {
    //Filter out normal leaves
    const fetchedLogs = await member.guild.fetchAuditLogs({
        limit: 1,
        type: 'MEMBER_KICK',
    });
    const kickLog = fetchedLogs.entries.first();
    if (!kickLog) return;
    if (kickLog.createdAt < member.joinedAt) {
        return;
    }
    const {executor, target, reason} = kickLog;
    if (target.id != member.id) {
        Console.discordLog(`${member.user.tag} left the guild, audit log fetch was inconclusive.`, member.guild.id);
        return;
    }
    if (executor.id == Client.user.id) return;
    //Log the kick
    modActions.modLog('Kick', member.user, executor, reason, member.guild, null, false);
});
BotListeners.on('guildBanAdd', async function (/** @type {import('discord.js').GuildBan} */ ban) {
    const fetchedLogs = await ban.guild.fetchAuditLogs({
        limit: 1,
        type: 'MEMBER_BAN',
    });
    const banLog = fetchedLogs.entries.first();
    if (!banLog) return;
    const {executor, target, reason} = banLog;
    if (target.id != ban.user.id) {
        Console.discordLog(`${ban.user.tag} was banned, audit log fetch was inconclusive.`, ban.guild.id);
        return;
    }
    if (executor.id == Client.user.id) return;
    //Log the ban
    modActions.modLog('Ban', ban.user, executor, reason, ban.guild, null, false);
});
BotListeners.on('guildBanRemove', async function (/** @type {import('discord.js').GuildBan} */ ban) {
    const fetchedLogs = await ban.guild.fetchAuditLogs({
        limit: 1,
        type: 'MEMBER_UNBAN',
    });
    const banLog = fetchedLogs.entries.first();
    if (!banLog) return;
    const {executor, target, reason} = banLog;
    if (target.id != ban.user.id) {
        Console.discordLog(`${ban.user.tag} was banned, audit log fetch was inconclusive.`, ban.guild.id);
        return;
    }
    if (executor.id == Client.user.id) return;
    //Log the ban
    modActions.doUndoAction('Ban', ban.user.id, ban.user.tag, executor, reason, null, ban.guild);
});
