//Set general log channel
//Set mod log channel
//Set mod role
