//Log message edit
//Log message delete
//Log manual ban
//Log manual kick
//Log manual timeout and dm user
