const {StorageManager, Console, ExportManager} = Bot;
const {CommandManager, ChatResponder, Client, BotListeners} = Discord;
const {MessageEmbed} = require('discord.js');
const modFunctions = require('./functions');
const modActions = require('./modActions');
const maxPercent = 80;

var latestUsernames = [];
var joinTimes = [];
//Remove after 5 minutes
setInterval(() => {
    for (timeIndex in joinTimes) {
        if (joinTimes[timeIndex] + 5 * 60 * 1000 <= Date.now()) {
            joinTimes.splice(timeIndex);
            latestUsernames.splice(timeIndex);
        }
    }
}, 5 * 1000);
//Member join
BotListeners.on('guildMemberAdd', (/** @type {Discord.GuildMember} */ member) => {
    var username = member.user.username;
    var similar = similarity(username);
    if (similar) {
        modActions.modLog('Kick', member.user, Client.user, 'Raid protection', member.guild, null);
    }
    if (latestUsernames.length == 5) {
        latestUsernames.shift();
        joinTimes.shift();
    }
    joinTimes.push(Date.now());
    latestUsernames.push(username);
});

//Is name similar to list?
function similarity(name) {
    for (nameIndex in latestUsernames) {
        var percent;
        var otherName = latestUsernames[nameIndex];
        var longer = name;
        var shorter = otherName;
        if (name.length < otherName.length) {
            longer = otherName;
            shorter = name;
        }
        var similar = 0;
        for (char of longer) {
            let index = longer.indexOf(char);
            if (shorter.charAt(index).toLowerCase() == char.toLowerCase()) similar += 1;
        }
        percent = Math.round((similar / longer.length) * 100);
        if (percent >= maxPercent) return true;
    }
    return false;
}
