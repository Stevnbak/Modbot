const {StorageManager, Console, ExportManager} = Bot;
const {CommandManager, ChatResponder, Client, BotListeners} = Discord;
const {MessageEmbed} = require('discord.js');
const modFunctions = require('./functions');
const modActions = require('./modActions');
//Kick
CommandManager.add('kick', {description: 'Kick member', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    let modUser = message.member;
    let content = message.content.replace(CommandManager.prefix + 'kick ', '');
    let params = content.split(' ');
    message.guild.members
        .fetch(params[0])
        .then((actionUser) => {
            let reason = content.replace(params[0] + ' ', '');
            if (!modFunctions.permissionCheck(modUser, actionUser)) return;
            message.delete();
            modActions.modLog('Kick', actionUser.user, modUser.user, reason, message.guild, message.channel);
        })
        .catch(() => {
            message.channel.send({embeds: [new MessageEmbed().setColor(neutralColor).setDescription(`User with id: '${params[0]}' could not be found`)]});
        });
});
//Ban
CommandManager.add('ban', {description: 'Ban member', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    let modUser = message.member;
    let content = message.content.replace(CommandManager.prefix + 'ban ', '');
    let params = content.split(' ');
    message.guild.members
        .fetch(params[0])
        .then((actionUser) => {
            if (!modFunctions.permissionCheck(modUser, actionUser)) return;
            let length = modFunctions.getLength(params[1]);
            let reason = '';
            console.log(length);
            if (length != -1) reason = content.replace(params[0] + ' ' + params[1] + ' ', '');
            else reason = content.replace(params[0] + ' ', '');
            message.delete();
            modActions.modLog('Ban', actionUser.user, modUser.user, reason, message.guild, message.channel, length);
        })
        .catch(() => {
            message.channel.send({embeds: [new MessageEmbed().setColor(modActions.neutralColor).setDescription(`User with id: '${params[0]}' could not be found`)]});
        });
});
//Mute/Timeout
CommandManager.add('mute', {description: 'Mute member', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    let modUser = message.member;
    let content = message.content.replace(CommandManager.prefix + 'mute ', '');
    let params = content.split(' ');
    message.guild.members
        .fetch(params[0])
        .then((actionUser) => {
            if (!modFunctions.permissionCheck(modUser, actionUser)) return;
            let length = modFunctions.getLength(params[1]);
            let reason = '';
            if (length != -1) reason = content.replace(params[0] + ' ' + params[1] + ' ', '');
            else reason = content.replace(params[0] + ' ', '');
            if (length == -1) length = 3600;
            message.delete();
            modActions.modLog('Mute', actionUser.user, modUser.user, reason, message.guild, message.channel, length);
        })
        .catch(() => {
            message.channel.send({embeds: [new MessageEmbed().setColor(modActions.neutralColor).setDescription(`User with id: '${params[0]}' could not be found`)]});
        });
});
//Warn
CommandManager.add('warn', {description: 'Warn member', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    let modUser = message.member;
    let content = message.content.replace(CommandManager.prefix + 'warn ', '');
    let params = content.split(' ');
    message.guild.members
        .fetch(params[0])
        .then((actionUser) => {
            let reason = content.replace(params[0] + ' ', '');
            if (!modFunctions.permissionCheck(modUser, actionUser)) return;
            message.delete();
            modActions.modLog('Warn', actionUser.user, modUser.user, reason, message.guild, message.channel);
        })
        .catch(() => {
            message.channel.send({embeds: [new MessageEmbed().setColor(modActions.neutralColor).setDescription(`User with id: '${params[0]}' could not be found`)]});
        });
});
//Modlog
CommandManager.add('modlogs', {description: 'Show modlogs for member', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    var modlogs = StorageManager.discordGet('modLog', message.guild.id) ? StorageManager.discordGet('modLog', message.guild.id) : {};
    var userId = message.content.replace(CommandManager.prefix + 'modlogs ', '').replace(CommandManager.prefix + 'modlogs');
    var currentLogs = modlogs[userId];
    if (currentLogs) {
        var msgEmbed = new MessageEmbed()
            .setColor(modActions.successColor)
            .setAuthor(`Modlogs for ${currentLogs[Object.keys(currentLogs)[0]]['username']}`)
            .setFooter(`Total logs: ${Object.keys(currentLogs).length}`);
        for (moderation in currentLogs) {
            var current = currentLogs[moderation];
            var length = '';
            if (current['length'] != -1) {
                length = `
Length: ${modFunctions.lengthToString(current['length'])}`;
            }
            msgEmbed.addField(
                `Case ${moderation}`,
                `Type: ${current['action']}
Moderator: <@${current['moderator']}>
Reason: ${current['reason']}${length}
Date: <t:${Math.round(current['date'] / 1000)}>`
            );
        }
        message.channel.send({embeds: [msgEmbed]});
        Console.discordLog(`Showed modlogs for ${current['username']}`, message.guild.id);
    } else {
        var msgEmbed = new MessageEmbed().setColor(modActions.failColor).setDescription(`No modlogs found for <@${userId}>`);
        message.channel.send({embeds: [msgEmbed]});
        Console.discordLog(`Couldn't find modlogs for ${userId}`, message.guild.id);
    }
    message.delete().catch(() => {});
});
//Active moderations
CommandManager.add('moderations', {description: 'Show all active moderations', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    var active = StorageManager.discordGet('activeMod', message.guild.id) ? StorageManager.discordGet('activeMod', message.guild.id) : {};
    var msgEmbed = new MessageEmbed()
        .setColor(modActions.successColor)
        .setAuthor(`Active moderations`)
        .setFooter(`Amount of active moderations: ${Object.keys(active).length}`);
    for (moderation in active) {
        var current = active[moderation];
        msgEmbed.addField(`Case ${moderation} | ${current['username']}`, `${current['action']} | Ends <t:${Math.round((current['date'] + current['length'] * 1000) / 1000)}:R>`);
    }
    message.channel.send({embeds: [msgEmbed]});
});
//Who is command
CommandManager.add('whois', {description: 'Show user information about user', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    var userId = message.content.replace(CommandManager.prefix + 'whois ', '');
    if (message.content == CommandManager.prefix + 'whois') userId = message.author.id;
    message.guild.members
        .fetch(userId)
        .then((member) => {
            var roles = [];
            member.roles.cache.forEach((role) => {
                if (role.name != '@everyone') roles.push(role);
            });
            var msgEmbed = new MessageEmbed()
                .setColor(modActions.neutralColor)
                .setThumbnail(member.user.avatarURL())
                .setAuthor(`${member.user.tag}`, member.user.avatarURL())
                .setDescription(`${member}`)
                .setFooter(`User id: ${member.id}`)
                .setTimestamp()
                .addFields([
                    {name: 'Joined', value: `<t:${Math.round(member.joinedTimestamp / 1000)}>`, inline: true},
                    {name: 'Registered', value: `<t:${Math.round(member.user.createdTimestamp / 1000)}>`, inline: true},
                    {name: 'Roles', value: `${roles.join(' ')}`},
                ]);
            message.channel.send({embeds: [msgEmbed]});
            Console.discordLog(`Showed user information for ${member.user.tag}`, message.guild.id);
        })
        .catch(() => {
            var msgEmbed = new MessageEmbed().setColor(modActions.failColor).setDescription(`Couldn't find user with id ${userId}`);
            message.channel.send({embeds: [msgEmbed]});
            Console.discordLog(`Couldn't find user with id: ${userId}`, message.guild.id);
        });
    message.delete().catch(() => {});
});
//Active moderations
CommandManager.add('moderations', {description: 'Show all active moderations', category: 'Moderation'}, (/** @type {import('discord.js').Message} */ message) => {
    var active = StorageManager.discordGet('activeMod', message.guild.id) ? StorageManager.discordGet('activeMod', message.guild.id) : {};
    var msgEmbed = new MessageEmbed()
        .setColor(modActions.successColor)
        .setAuthor(`Active moderations`)
        .setFooter(`Amount of active moderations: ${Object.keys(active).length}`);
    for (moderation in active) {
        var current = active[moderation];
        msgEmbed.addField(`Case ${moderation} | ${current['username']}`, `${current['action']} | Ends <t:${Math.round((current['date'] + current['length'] * 1000) / 1000)}:R>`);
    }
    message.channel.send({embeds: [msgEmbed]});
});
