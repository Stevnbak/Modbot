const {StorageManager, Console, ExportManager} = Bot;
const {CommandManager, ChatResponder, Client, BotListeners} = Discord;
const {MessageEmbed} = require('discord.js');
const modFunctions = require('./functions');
//Colours
const successColor = 0x239400;
const failColor = 0x910f00;
const neutralColor = 0x013370;
//Exports
module.exports = {
    modLog,
    doUndoAction,
    neutralColor,
    failColor,
    successColor,
};
//Log function
async function modLog(type, /** @type {Discord.User} */ user, /** @type {Discord.User} */ moderator, reason, guild, tempChannel, doAction = true, length = -1) {
    let typeMsg = type == 'Mute' ? 'muted in' : type == 'Kick' ? 'kicked from' : type == 'Ban' ? 'banned from' : type == 'Warn' ? 'warned in' : 'Error';
    //Save action
    saveAction(type, user.id, user.tag, moderator.id, reason, guild.id, length);
    //Console log
    var logMessage = `${user.tag} was ${typeMsg} ${guild.name} by ${moderator.tag} with the reason "${reason}"`;
    if (length != -1) logMessage += ` for ${length}`;
    Console.discordLog(logMessage, guild.id);
    //Channel stuff
    if (tempChannel) {
        if (!StorageManager.discordGet('modLogChannel', guild.id)) var channelId = tempChannel.id;
        else var channelId = StorageManager.discordGet('modLogChannel', guild.id);
    } else {
        var channelId = StorageManager.discordGet('modLogChannel', guild.id);
    }
    if (!channelId) {
        Console.discordLog(`No log channel set, and temp channel is null`, guild.id);
        return;
    }
    let channel = guild.channels.cache.get(channelId);
    if (tempChannel) tempChannel.send({embeds: [new MessageEmbed().setColor(neutralColor).setDescription(`${type} of ${user.tag} successful`)]});
    //Log
    var logEmbed = new MessageEmbed()
        .setColor(successColor)
        .setAuthor(`${type} | ${user.tag}`, user.avatarURL())
        .setFields([
            {
                name: 'User',
                value: `${user}`,
                inline: true,
            },
            {
                name: 'Moderator',
                value: `${moderator}`,
                inline: true,
            },
        ])
        .setTimestamp(new Date())
        .setFooter(`User ID: ${user.id}`);

    if (length != -1)
        logEmbed.addFields([
            {
                name: 'Length',
                value: `${modFunctions.lengthToString(length)}`,
                inline: true,
            },
        ]);
    //Dm user
    var dmEmbed = new MessageEmbed().setColor(failColor).setTitle(`You have been ${typeMsg} ${guild.name}`).setTimestamp(new Date());
    if (length != -1)
        dmEmbed.addFields([
            {
                name: 'Length',
                value: `${modFunctions.lengthToString(length)}`,
                inline: true,
            },
            {
                name: 'Reason',
                value: `${reason}`,
                inline: true,
            },
        ]);
    else dmEmbed.addField('Reason', `${reason}`, false);
    await user
        .send({embeds: [dmEmbed]})
        .then(() => {
            logEmbed.addField('DM Status', 'Succesful', true);
        })
        .catch(() => {
            logEmbed.addField('DM Status', 'Failed', true);
        });
    //Rest of log
    logEmbed.addField('Reason', `${reason}`, true);
    channel.send({embeds: [logEmbed]});
    //Do the action
    if (doAction) {
        var guildUser = await guild.members.fetch(user.id);
        doNormalAction(type, guildUser, reason, length);
    }
}
//Save mod action
function saveAction(action, userId, username, moderatorId, reason, guildId, length) {
    var caseId = StorageManager.discordGet('currentModCount', guildId) ? StorageManager.discordGet('currentModCount', guildId) + 1 : 1;
    StorageManager.discordSet('currentModCount', caseId, guildId);
    //Active
    if (length != -1) {
        var activeActions = StorageManager.discordGet('activeMod', guildId) ? StorageManager.discordGet('activeMod', guildId) : {};
        activeActions[caseId] = {};
        activeActions[caseId]['date'] = Date.now();
        activeActions[caseId]['action'] = action;
        activeActions[caseId]['length'] = length;
        activeActions[caseId]['userId'] = userId;
        activeActions[caseId]['username'] = username;
        StorageManager.discordSet('activeMod', activeActions, guildId);
    }
    //log
    var modLog = StorageManager.discordGet('modLog', guildId) ? StorageManager.discordGet('modLog', guildId) : {};
    if (!modLog[userId]) modLog[userId] = {};
    modLog[userId][caseId] = {};
    modLog[userId][caseId]['date'] = Date.now();
    modLog[userId][caseId]['action'] = action;
    modLog[userId][caseId]['length'] = length;
    modLog[userId][caseId]['username'] = username;
    modLog[userId][caseId]['moderator'] = moderatorId;
    modLog[userId][caseId]['reason'] = reason;
    StorageManager.discordSet('modLog', modLog, guildId);
}
//Do normal Action
function doNormalAction(action, user, reason, length) {
    if (action == 'Ban') user.ban({days: 1, reason: `${reason}`});
    //if (action == 'Mute') user.timeout(length, `${reason}`);
    if (action == 'Kick') user.kick(reason);
}
//Do undo Action
async function doUndoAction(type, userId, username, moderator, reason, tempChannel, guild) {
    //Do the action
    if (moderator.id == Client.user.id || tempChannel) {
        //if (type == 'Ban') user.unban(reason);
        //if (type == 'Mute') user.removeTimeout(reason);
    }
    let typeMsg = type == 'Mute' ? 'unmuted in' : type == 'Ban' ? 'unbanned from' : 'Error';
    //Console log
    var logMessage = `${username} was ${typeMsg} ${guild.name} by ${moderator.username} with the reason "${reason}"`;
    Console.discordLog(logMessage, guild.id);
    //Channel stuff
    if (tempChannel) {
        if (!StorageManager.discordGet('modLogChannel', guild.id)) var channelId = tempChannel.id;
        else var channelId = StorageManager.discordGet('modLogChannel', guild.id);
    } else {
        var channelId = StorageManager.discordGet('modLogChannel', guild.id);
    }
    if (!channelId) {
        Console.discordLog(`No log channel set, and temp channel is null`, guild.id);
        return;
    }
    let channel = guild.channels.cache.get(channelId);
    if (tempChannel) tempChannel.send({embeds: [new MessageEmbed().setColor(neutralColor).setDescription(`Un${type.toLowerCase()} of ${user.tag} successful`)]});
    //Log
    var logEmbed = new MessageEmbed()
        .setColor(successColor)
        .setAuthor(`Un${type.toLowerCase()} | ${username}`)
        .setFields([
            {
                name: 'User',
                value: `<@${userId}>`,
                inline: true,
            },
            {
                name: 'Moderator',
                value: `${moderator}`,
                inline: true,
            },
            {
                name: 'Reason',
                value: `${reason}`,
                inline: true,
            },
        ])
        .setTimestamp(new Date())
        .setFooter(`User ID: ${userId}`);

    channel.send({embeds: [logEmbed]});
}
