const io = require('@pm2/io');
const {Client} = Bot;

const currentUsers = io.metric({
    name: 'Current Users',
    id: 'app/realtime/users',
    historic: true,
});
const currentServers = io.metric({
    name: 'Current Servers',
    id: 'app/realtime/guilds',
    historic: true,
});
updateMetrics();
setInterval(updateMetrics, 5 * 60 * 1000);
function updateMetrics() {
    console.log('Updating metrics');
    Client.guilds.fetch();
    currentServers.set(Client.guilds.cache.size);
    console.log(Client.guild.cache);
    var users = 0;
    Client.guilds.cache.forEach((guild) => {
        users += guild.memberCount;
    });
    currentUsers.set(users);
}
